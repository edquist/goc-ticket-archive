import FWCore.ParameterSet.Config as cms
import pickle
handle = open('PSet.pkl', 'rb')
process = pickle.load(handle)
handle.close()
